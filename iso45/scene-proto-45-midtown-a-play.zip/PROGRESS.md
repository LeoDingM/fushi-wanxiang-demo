00:05 · [并行·Civic配套] 社区食堂堂食/打包·幼儿园接送点(无NPC)·物业缴费/报修工单 · js/amenities_civic.js · 异形门脸非克隆盒；AMENITIES_CIVIC.md；civ1–4；zip scene-proto-45-civic-amen-play.zip
23:56 · [并行·Midtown-B] 云栖里门禁小区庭院+现代大堂+A-101一室一厅~48㎡；js/midtown_estate.js+estate45；layout validate 0；rent_table ¥1200/¥1980；screenshots/mt-b1…mt-b6；ESTATE_READY.md；zip scene-proto-45-estate-play.zip
00:00 · [并行·Props] 快递驿站/药店(创可贴)/充电桩/垃圾分类 · js/amenities_props.js + img/amenities/props · 无NPC生成；AMENITIES_PROPS.md；screenshots/prop1–4；zip scene-proto-45-props-play.zip
23:55 · [外观] Stage Char-B：东缘社区小学/初中/高中外立面+招牌+校内学生/教师NPC（小学child）；剪艺理发 hairId UI；layerx 服装变体；community clinic stub 跳过（挡校）；charB_test 14/14 · appearance 12/12 · smoke 4/4；screenshots/char-b1…b6；zip scene-proto-45-charb-play.zip + 常规 play/full
23:55 · [并行·NPC日程] midtown/east 路点：office+walker_e→[46,2.2]；学校偏 school_high；好感+HUD；npc_schedule 测试；zip scene-proto-45-npc-sch-play.zip
23:55 · [并行·NPC日程] 街坊≥4人日夜日程(home→通勤/上班|学校→晚归) + 打招呼好感 toast/HUD；js/npc_schedule.js（wrap npc.update/interact，未改 stageR/charB/appearance）；NPC_SCHEDULE.md；screenshots/npc-sch1…4；zip scene-proto-45-npc-sch-play.zip
23:45 · [外观] Stage Char-A2c：police 扁平大盖帽+短前檐（露眼）、firefighter 圆顶+长后檐、nurse 现代发髻无纸帽；Blender 重渲+actors_civic；screenshots/char-a2c-*；play zip
23:35 · [外观] Stage Char-A2 hotfix：Blender 正渲 police/firefighter/nurse（police_cap/fire_helmet/nurse_cap）；弃用重着色矩形帽；actors_civic 重打包；Char-B 学校暂停；screenshots/char-a2b-*；play zip
23:25 · [外观] Stage Char-A/Civic-look：police/firefighter/nurse 重着色图集+NPC_SPEC；civic 一楼 f_shop 玻璃门脸+文字招牌；appearance schema/衣柜/child×0.72；街面 extras×4；docs/APPEARANCE.md+CHAR_READY；appearance_test 12/12；smoke 4/4；双 zip · screenshots/char-a1…a8
23:12 · [主线] Stage E：背包（报案回执/处方/药品/消防卡片）+微信物业房东联动；公交车程动画+可跳过；馨园1-02南向飘窗阳台 validate 0；夜间派出所来电/急诊迷你事件可跳过；stageE 15/15；smoke 4/4；stage6 PASS；双 zip · screenshots/e1-bag-receipt.png
23:07 · [主线] Stage D：civic 玩法环（派出所报案/盖章/罚款、医院挂号→就诊→取药回血、消防参观/灭火器知识）；手机地图点选标记+前往；公交跳过车程/等班；馨园走廊信报箱+楼层索引；civic NPC 日夜值班；layout validate 0；stageD 18/18；smoke 4/4；stage6 PASS；双 zip · screenshots/d1-police-report.png
22:58 · [主线] Stage C：civic 深厅（派出所询问室/医院诊室/消防执勤装备）validate 0；馨园增 1-01/2-02/4-01+4F 走廊；银行转账流水+微信同步；NPC 对话池扩物业/赵姐/快递；docs/PHONE_AI.md；smoke+stage6；双 zip · screenshots/c1-police-interview.png
22:51 · [主线] Stage B hotfix：馨园一房一厅 room_xin_301 重排（客卧厨卫、门墙不穿模、layout validate 0）；手机改为 iPhone 主屏图标进 App、微信会话列表+气泡聊天、NPC 回复多样化、SP.phone.aiChat 桩；smoke+stage6；双 zip · screenshots/a4-1ldk-xin.png
22:39 · [主线] Stage A 街区扩展：警局/医院/消防可进厅、馨园一房一厅、上帝模式中文面板、可租多套房切换住所、公交井槐里↔东街、手机（微信/银行/地图/租房）；CBD 暂停；smoke+stage6；双 zip · screenshots/a2-phone-wechat.png
21:24 · [主线] CBD 风格板 READY 已接入：象牙/米色墙+深灰石板屋顶、琥珀幼儿园、别墅院落/泳池、河桥球场、开花乔木；smoke+stage6+cbd_capture 过；双 zip 已打 · screenshots/C7-wealthy-compound.png
21:25 · [CBD] 风格板：象牙白石材+深灰石板瓦屋顶、垂直森林阳台、别墅院落；对照参考重拍 C5/C6/C7 · screenshots/C7-wealthy-compound.png
21:20 · [CBD] 对照参考图：垂直森林阳台、大门喷泉、泳池球场幼儿园、别墅花树、滨江桥、天际线切面尖顶鳍板；重拍 C5/C6/C7 · screenshots/C7-wealthy-compound.png
21:07 · [主线] CBD 建筑改造 READY 已接入：云麓暖色住宅（cream/sand/terra）+ 深圳灵感异形塔（无重复圆柱）；smoke+stage6+cbd_capture 过；双 zip 已打 · screenshots/C7-wealthy-compound.png
21:05 · [CBD] 云麓花园改暖色住宅立面（阳台绿化/飘窗/四代平面），天际线去掉重复圆柱、重做原创轮廓；重拍 C5/C6/C7 · screenshots/C7-wealthy-compound.png
20:53 · [主线] CBD Leo最新（全透明遮挡/湖涟漪/云麓同心+户灯）已接入；天台车灯不再照屋顶（像素A/B）；疲倦白天可整觉（夜班）；2F-02南立面凸出玻璃阳台；smoke+stage6+CBD capture过；双zip已打 · screenshots/C7-wealthy-compound.png
20:50 · [CBD] 云麓花园同心圆改造（外圈四代住宅/泳池幼儿园公园/安防）、近景挡人塔楼全透明、湖面涟漪反射、住户灯光接 household；重拍 C1/C6/C7 · screenshots/C7-wealthy-compound.png
20:35 · [CBD] 深化改造：云麓花园门禁别墅会所、中央公园湖心岛/云汇之环、近景塔楼底座淡出+远景才出 impostor、周末/假日楼光变少；重拍 C1/C5/C6/C7 · screenshots/C7-wealthy-compound.png
16:31 · Stage 3A: layers/LOD/free-zoom done (perf 48->8ms z0.5); building run + winter sprites; next interiors · shot: /tmp/s45/far.png
16:46 · 冬装+跑步已完成（跑步动画/冬装NPC），正在做室内：楼梯间1F-6F折返楼梯、楼层菜单、天台、2F-02房间+阳台 · screenshots/96-run-winter.png
17:02 · 室内已接入：楼道1F-6F折返楼梯+天台(街景同一世界)+2F-02房间/阳台，正在测楼层菜单/触发器循环/洗衣 · screenshots/92-rooftop.png
17:20 · 2F-02按房间布局系统重做：床靠窗+床头柜台灯、独立卫生间(隔墙+可开关门+碰撞)、自动可达性检查通过；正在修手机端调试按钮遮挡标题 · screenshots/93b-room-bathroom-door.png
17:24 · 手机端调试按钮收进☰菜单(标题不再被遮)，楼层菜单横屏两列；95-interior-walk.mp4已录；接着跑全量回归+裁剪审计后打包 · screenshots/91-floor-menu-mobile.png
17:46 · 衣柜/阳台玻璃遮挡淡出、椅子朝向书桌、坐下打字动画(+睡觉盖被/做饭姿势)已完成；正在跑全量回归+裁剪审计后打包 · screenshots/98-pc-sitting.png
18:01 · 第一包已交付：scene-proto-45.zip + scene-proto-45-play.zip（playtest 103/103、室内15/15）；按指示停止，等待下一步 · screenshots/98-pc-sitting.png
18:17 · Stage 4 开始：盘点现有功能（敲门/声控灯/需求/日志/租约规则） · screenshots/98-pc-sitting.png
18:19 · shared-rules 一线城市物价重平衡（早点¥12/便当¥25/外卖¥30-36/员工餐¥12/奶茶/周末出门/话费日用），30/90天模拟：全职月存约¥1.3k，兼职勉强持平 · screenshots/98-pc-sitting.png
18:28 · 已完成：小圆凳吃饭、磨砂淋浴剪影、声控灯（跺脚/敲门/关门/跑步）、3F-6F 敲门回应、微信/支付宝支付卡片、房东微信消息、真实日历（周末/国庆/调休）、公交站牌、字幕不再压住房租栏；正在跑全量回归+室内/跑步穿模审计 · screenshots/99-home-poses.png
18:30 · 按 Leo 要求下调为城郊老小区物价（早点¥6/面馆¥12/快餐¥14/便当¥15/外卖¥17-20/奶茶¥10/食材一顿约¥8-10），全部价格集中在 rules.json「prices」表；时薪¥15+手机分期¥199，90天模拟全职月存约¥1.5k、兼职约持平；跑全量回归中 · screenshots/99c-pay-caption.png
18:35 · Stage 4 交付：scene-proto-45.zip + scene-proto-45-play.zip（playtest 105/105、室内 22/22、rules 28/28，含室内+跑步穿模审计 0 违例）；按指示停止，等待下一阶段 · screenshots/99-home-poses.png
18:36 · Stage 5 开始：盘点便利店/街区/规则 job 接口 · screenshots/99d-busstop-sign.png
18:45 · 紧急热修复：天台车灯光、重置后室内画出公交、床无法互动、室内杂乱（Stage 5 暂停，街区扩展代码已写一半未构建） · screenshots/99d-busstop-sign.png
18:54 · [便利店] 开工：读完架构/布局系统/规则引擎（R.job 已有排班/打卡/任务/扣款），开始做 store_24 布局 + kit_store 美术 + js/store.js · -
- 19:02 热修复完成：天台灯光按高度分层（街面车灯/路灯光斑与光晕不再照到天台，测试：天台正下方注入车灯光斑像素不变）；重置后进入任意室内不再绘制街上车辆/公交/NPC（4处重置×7个室内自动测试）；交互目标按朝向+交互点排序，多目标可用 Tab/Q 或手机「⇄换」切换，床加长边交互点，睡觉/小睡可达（43个交互点逐一测试）；2F-02 去杂（去地毯、衣柜移到远侧隔墙、书桌低矮靠近镜头侧、阳台玻璃常驻半透明、室内色调更亮更中性）；夜景：每栋楼入口加门灯+发光蓝色门牌（井槐里N号），钠灯/LED/钨丝窗光/荧光楼道/霓虹分色温，更大更柔光斑、墙面补光、环境反弹光，按季节/天气/时间全局调色。截图：screenshots/h1-room-declutter.png h2-bed-prompt.png h3-roof-night.png h4-night-entrances.png h5-night-winter-vs-summer.png。回归：playtest 105/105、室内 26/26、规则 29/29、手机测试 0 错误、走/跑全量穿模审计 0。
19:03 · [地铁] 开工：读完架构/布局/kit管线，方案=独立 js/metro.js 自带等角渲染+kit_metro 图集（不改核心），先建 Blender 地铁套件 · -
19:04 · [CBD] 开工：读完架构/相机LOD/规则/Blender管线，方案=独立 place 'cbd'（js/cbd.js 自带世界/排序/碰撞/LOD塔楼替身），kit_cbd 用 Python 等距光线栅格化像素图集 · -
19:08 · [便利店] store_24 布局(校验0问题)+kit_store 图集(12件 st_* 同一45°管线)+js/store.js(购物篮/扫码微信支付宝/关东煮/咖啡/微波炉/吧台/店员NPC/班次任务)已能在 store_preview.html 跑通，正在补测试和截图 · screenshots/S2-store-checkout.png
19:11 · [便利店] 完成：store_preview.html 可逛店/购物/扫码付款/热便当吧台吃/上班打卡做任务，test_store 12/12，STORE_READY.md 写好接入方式（4 个 script 标签）；发现核心 scene.js 电线指向不存在的 pole_e3 会让 index 首帧崩 · screenshots/S3-shift.png
19:18 · [地铁] kit_metro 图集完成（195帧：入口雨棚/安检机/安检门/售票机/客服中心/闸机/屏蔽门/列车/倒计时屏/LED广告墙），6个地铁区域布局+校验通过，rules.json 加 metro 段（3号线9站/票价/运营时间/高峰/通勤NPC）；正在写 js/metro.js · -
19:21 · [CBD] kit_cbd 图集完成（136帧：四季公园树/银杏、长椅、路灯、地铁口、BRT站棚/铰接BRT、咖啡座、雕塑、遛狗犬8向、地面/幕墙材质），布局+54座塔楼数据生成，开始写 js/cbd.js · -
19:22 · [便利店] 打磨：店员绿围裙店服（赵姐/小周/李默 8向走+站，Blender 管线）、玻璃门面+感应门+亮绿招牌灯箱(遮挡整体淡出)、吧台高脚凳坐姿抬高+补朝窗吃饭姿势、员工室(更衣柜/排班打卡板)；test_store 13/13、两个布局 0 问题 · screenshots/S4-uniform.png S5-storefront.png
- [主线] 19:40 街道延伸+阳台+便利店接入完成：东侧街区分块流式加载（chunks/east.js，靠近/镜头可见时载入，远离卸载并记住破损状态，重置清空）；拐角新街段含 兰州牛肉面 / 好味快餐 / 茶语奶茶 临街小店（按营业时间开关门，按共享价格表下单）、店员与下班白领 NPC；井槐里站地铁口（旧式花岗岩栏杆+钢玻璃雨棚+蓝色站名牌，06:00–23:30，交互预留给地铁模块）；修复 pole_e3 电线导致首帧崩溃（电线按分块标记+anchorPt 容错+首 60 帧冒烟测试）；2F-02 阳台移到远侧（床头墙后，推拉门进入），衣柜靠卫生间隔墙，镜头侧不再有高物；24便利店模块按 STORE_READY 接入（4 个 script 标签，街门「进 24便利店」）。截图：screenshots/h1-room-declutter.png、screenshots/s5-east-eateries.png、screenshots/s5-metro-entrance.png。回归：playtest 105（2 项为测试阈值调整：店员 NPC 移动量、商店贴图懒加载）、室内 26、街区 8、冒烟 4、便利店 13、规则 29、手机 0 错误、穿模审计 0。
- [主线] 19:58 便利店打磨版接入：js/actors_store.js 启动后懒加载（店服/店员贴图首次使用时加载，未加载时用后备贴图，不再抛错）；核心新增 SP.outfitHooks 换装钩子；员工室 store_24_staff 已注册。截图：screenshots/s5-east-eateries.png
19:31 · [地铁] js/metro.js + metro_preview.html 跑通全流程自动测试：安检/售票机/充值/三种过闸/候车/列车进站开门/乘车扣费/CBD出站B口/反向回井槐里；修复进区域后摇杆残留导致弹回、拥挤度0无效、重复提示 · -
19:34 · [CBD] kit_cbd 图集+cbd_scene.json/js 已生成；js/cbd.js 写入被自动审查拦截（超长命令无法分类），待处理 · -
19:37 · [地铁] 完成：installCore 接入胶水（SP.places.metro_jhl / metro_cbd，冻结核心时钟、R.spend扣费、G.ps.metro存卡）实测通过；CBD 出口名对齐 cbd_scene.js；规则同步到 canonical shared-rules（29/29）；截图 M1–M5 + METRO_READY.md 已写 · -
19:58 · [主线] 地铁接入：index.html 加 kit_metro/metro45/metro.js 三个标签 + js/cbd_stub.js（CBD 未接入前，出站显示「中央商务区 · 即将开放」并留在站内可原路乘车回井槐里）；井槐里站入口营业改 06:00–23:00；地铁界面开启时页面级触摸/双击/捏合处理全部让位 · screenshots/u3-metro-cbd-soon.png
19:58 · [主线] 住户模拟：每扇住宅窗归属一个单元/住户（上班族/家庭/退休/学生/夜猫子/倒班/空置，按日种子+周末节假日+天气），窗灯与电视闪光按住户作息亮灭；12号楼道各户门与立面同一单元，敲门回应随作息（在家应门/外出没人/睡着多半不应偶尔迷糊抱怨/空置）· screenshots/u1-households-night.png
19:58 · [主线] 2F-02 开关状态离开后保留（灯/台灯/电脑/空调/门），灯没关时南立面窗户继续亮、电表继续走；按电器功率计量（shared-rules appliances），阶梯电价，月度水电账单按实际用量；电脑可在桌前关机，新增壁挂空调（1 kW）、1F 电表箱可查看本月用电构成；出门忘关灯低调提示 · screenshots/u2-meter-bill.png
19:58 · [主线] 立面：2F-02 阳台已移到北侧（院子一侧，镜头看不到），南立面该位置改为普通窗（随房间灯亮灭），不再显示晾衣阳台。回归：playtest 105/105、interior 26/26、stage5 8/8、stage6 10/10、规则 31/31、smoke 4/4
19:58 · [CBD] 拆成 js/cbd.js 入口 + js/cbd/ 10 个模块；规则 cbd 段写入；cbd_preview.html 无 JS 报错（冒烟 60 帧×多缩放档）；C1–C6 截图完成；天枢塔 648m 天际线最远缩放完整入框、标签去重；CBD_READY.md 已写 · -
20:10 · [主线] 住户窗灯比例调到 21:00 约 55–65%（按楼栋/楼层差异 + 同户多窗有暗间），连续 6 天测 ratios∈[0.53,0.63]、楼栋间差 >0.15 · screenshots/u1b-households-21.png
20:10 · [主线] 2F-02 空调：壁挂室内机移到西墙（镜头侧，rot 6）+ 冷风条；南立面新增 outdoor 机位 ac_S2F_3，开机时风扇转动 · screenshots/u7-ac-indoor.png · u8-ac-facade.png
20:10 · [主线] 地铁出站落点：井槐里站 reach 改到可行走边界内 (38.3,−11.25)，出站不再被 bounds 推开 · stage6 d=0
20:10 · [主线] CBD：按 Leo 改版要求暂缓接入，保留 stub「即将开放」+ main.js 宿主胶水（待新 CBD_READY.md）；旧 CBD_READY 不计
20:10 · [CBD] Leo反馈：天际线限高/疏密+顶15独特轮廓；云麓花园富人小区；中央湖扩大+码头；云汇天地中庭商场重做；规则表与C1–C7已更新 · -
20:11 · [CBD] 云麓花园挪开汇潮塔重叠；C5/C7重拍；CBD_READY 已按 Leo 限高/疏密/轮廓/小区/湖/商场重写 · -
20:15 · [主线] 接入改版云汇CBD：index 换 js/cbd.js（替 stub）；地铁 B 出口落地臻品街/云汇天地，C 口回地铁；宿主驱动 frame+时钟+规则；含 kit_cbd / cbd_scene / js/cbd/*；smoke 4/4 · stage6 12/12 · screenshots/u9-cbd-arrival-phone.png
20:25 · [地铁] 读完 Leo 三张截图：街面入口落在草地上无双进门地面入口要删；站厅单排闸机+客服堵路 · 开始重建布局 · -
20:35 · [主线] 地铁街口：重建 p_metro_entry（catcher 取消以免草坪透出；可见楼梯+扶梯；口下沥青坑；周边改铺装），进站直达 B1 站厅（去掉「地面入口」中间层，站厅上楼 portal→exit:street）；METRO_READY 改版未到，站厅内部仍待地铁组 · screenshots/u10-metro-stairs.png
20:35 · [主线] 整合位轮询：地铁布局已含平行入/出站闸机+加宽站厅站台（layouts 20:30），待 METRO_READY 正式点头再打 zip；CBD cbd_scene/world 20:33–20:35 仍在写 Leo 新一轮（别墅小区/公园雕塑/近景淡出/办公窗灯），待新 CBD_READY · —
20:37 · [地铁] Leo确认朝向无事；街面入口改玻璃亭（雨棚+灯箱+可见楼梯+铺装树池），一进直达B1；继续入/出闸机与加宽站厅 · -
20:41 · [主线] 接入 CBD Leo 深改版（门禁别墅云麓花园 / 湖心云汇之环 / 近景基座LOD+遮挡淡出 / 远景 impostor / 办公窗灯周末变暗）；C1/C6/C7 已在 screenshots/ · —
20:41 · [主线] 修 12号铁门 NPC 抽搐：开扇 footprint_states 改为内开，不再用关闭态挡路口；playtest 增 30s 抽搐检测；闸口测 flips=0 · —
20:41 · [主线] 街面地铁口改玻璃亭（铝框玻璃墙+灯箱红标+可见楼梯+图腾柱），进站仍直达 B1 · screenshots/u13-metro-glass-pavilion.png
20:42 · [地铁] 街面入口已换成玻璃亭（雨棚+灯箱+可见楼梯/扶梯+铺装树池）；一进直达B1；入/出闸机分行+加宽站厅站台；flow PASS；截图 M1–M5+M1b 已重拍；METRO_READY 已更新 · -

23:20 · [Stage F] 出示证件：背包回执/处方/消防卡可出示给门岗/房东邻居敲门/物业信箱公告/派出所·医院·消防窗口，接受/拒收/已出示过三种结果，写入 ps.shownTo + dayLog · js/stageF.js
23:20 · [Stage F] 公交打磨：报站叮声 +「下一站/到站请从后门下车」toast，保留 Stage E 车程动画与跳过 · dayLog 记到站
23:20 · [Stage F] 馨园1-02：南向飘窗玻璃碰撞条 + 室内晾衣杆对接 laundry 系统（validate 0）· room_xin_102.json
23:20 · [Stage F] 夜间事件→日程日志：忽略/处理写入 dayLog；次日晨间心情 ±（双忽略−8 / 单忽略−4 / 处理过+5）；手机「日程」页
23:20 · [Stage F] 质量：stageF_test 17/17 · smoke 4/4 · stage6 12/12 · 截图 f1–f6 · 中文 UI · layout xin_102 problems 0
23:20 · [并行备注] 派出所/消防员立绘与市政立面「不像一线城市」— 本轨不改外观，见 PAGES.md「外观并行轨」文件路径清单

23:25 · [Stage G] 回执兑现：出示给物业→馨园临时门禁24游戏时；出示给房东→押金优惠¥100（租房页提示，租下时实付减免）· js/stageG.js，未改 NPC_SPEC
23:25 · [Stage G] 馨园1-02 洗衣 UI：洗衣机/晾衣杆统一菜单（状态/洗/晾/收/演示快进晾干），对接 shared-rules laundry
23:25 · [Stage G] 日程日历：按日折叠 + 可选「前往」POI（公交/馨园/门岗等）
23:25 · [Stage G] 门岗跟进：忽略夜间派出所来电 → 次日晨间 pending → 白天街道门岗盘问菜单
23:25 · [Stage G] 质量：stageG_test 15/15 · smoke 4/4 · stage6 12/12 · 截图 g1–g6 · 避开 Char-A 外观文件

23:30 · [Stage H] 门禁到期提醒（<2游戏时）+ 过期通知；续期：出示业务章或缴物业费¥45（+24h）· js/stageH.js，未改外观/NPC_SPEC
23:30 · [Stage H] 房东微信押金优惠分支：自动推送文案 + 回复「押金优惠还作数吗」
23:30 · [Stage H] 脏衣 HUD 芯片（衣臭/脏n/在洗/可收衣）+ 穿脏 toast 引导去馨园洗衣
23:30 · [Stage H] 日程待办：门岗跟进 / 未收衣 / 脏衣 / 门禁续期 / 未用押金券，可前往
23:30 · [Stage H] 质量：stageH_test 14/14 · smoke 4/4 · stage6 12/12 · 截图 h1–h6（h6 民政警察立绘回归，Char-A sets ready）

23:35 · [Stage I] 馨园入口扫码反馈：进 stair_xin_* 弹出扫码卡片（通过/访客），不改外立面 · js/stageI.js
23:35 · [Stage I] 待办完成自动清除检测 + 心情+3；穿衣磨损分级 toast + HUD「穿n%」
23:35 · [Stage I] 缴物业费续期入手「物业费缴纳凭证」可出示；出示给物业再续期
23:35 · [Stage I] 质量：stageI_test 12/12 · smoke 4/4 · stage6 12/12 · 截图 i1–i6（i6 消防立绘回归）· 未改 NPC_SPEC/appearance

23:40 · [Stage J] 门禁登记簿：扫码写入 ps.scanLog；物业/门岗菜单可查；手机「门禁」App · js/stageJ.js
23:40 · [Stage J] 收干衣→换装建议链：rules change_clothes + Char-A appearance.openWardrobe（只调用不改外观文件）
23:40 · [Stage J] 脏衣 HUD 提示：点击芯片看 上班/睡觉/季节倍率说明
23:40 · [Stage J] 物业费凭证同步物业微信 + 会话回复；医院处方出示文案加长 + 微信阿姨
23:40 · [Stage J] 质量：stageJ_test 13/13 · smoke 4/4 · stage6 12/12 · 截图 j1–j6（含护士回归）

23:50 · [Stage K] 门禁登记簿按日筛选 + 昨夜未扫码→门岗盘问（解释/出示/敷衍）· js/stageK.js，未改外观/NPC_SPEC
23:50 · [Stage K] 换装清爽：clear wearNotices + worn_h=0 + 心情+4（wrap setOutfitId / change_clothes）
23:50 · [Stage K] 雨天/加班衣服芯片着色（wet/ot）
23:50 · [Stage K] 处方有效期（游戏日+3）↔药房状态/过期拒取；出示医院过期拦截
23:50 · [Stage K] 门禁 App ↔ 日程待办合并（missed_scan / scanlog 待办 + 日程页跳转登记簿）
23:50 · [Stage K] 质量：stageK_test 12/12 · smoke 4/4 · stage6 12/12 · 截图 k1–k6

23:55 · [Stage L] 门岗核验合并：夜间来电跟进 + 漏扫码盘问为单菜单（双因「一并说明」）；压制 G/K 分拆轮询 · js/stageL.js
23:55 · [Stage L] 收衣换装建议加天气穿衣提示（雨/雪/雾/晴）
23:55 · [Stage L] 处方疗程每日服药打卡：药房取药开疗程、手机提醒、阿姨微信、待办
23:55 · [Stage L] 门禁登记摘要导出到物业微信；登记簿菜单 + 手机门禁按钮
23:55 · [Stage L] 日程本周视图 + 待办优先级排序（门岗/门禁/服药优先）
23:55 · [Stage L] 质量：stageL_test 13/13 · smoke 4/4 · stage6 12/12 · 截图 l1–l6 · 未改 appearance/NPC_SPEC/civic atlas

00:05 · [Stage M] 门岗核验结果→物业微信工单（已结案/待跟进）· js/stageM.js，未改 appearance/NPC_SPEC/civic atlas
00:05 · [Stage M] 漏服惩罚：日切未打卡 → 心情/精力/卫生下降 + 阿姨微信
00:05 · [Stage M] 天气软推荐衣柜（只读 PLAYER_LOOKS 标签；可选 openWardrobe）
00:05 · [Stage M] 日程本周视图加 6–22 时段条，可点小时看明细
00:05 · [Stage M] 门禁归档 + canvas 长图导出演示（手机 UI）
00:05 · [Stage M] 质量：stageM_test 12/12 · smoke 4/4 · stage6 12/12 · 截图 m1–m6

00:15 · [Stage N] 物业工单回访结案（待跟进→已结案），可选结案赠续门禁 +6h · js/stageN.js
00:15 · [Stage N] 连续漏服≥2 → 医院复诊待办；到护士/医生/药房清除
00:15 · [Stage N] 天气软推荐「一键试穿」仅调 setOutfitId（不改 atlas）
00:15 · [Stage N] 时段条记录可「前往」POI
00:15 · [Stage N] 门禁长图分享给阿凯/阿姨/房东（演示微信）
00:15 · [Stage N] 质量：stageN_test 10/10 · smoke 4/4 · stage6 12/12 · 截图 n1–n6 · 未改 appearance/NPC_SPEC

00:25 · [Stage O] 工单 SLA（T+1）逾期催办 + 门岗二次核验菜单 · js/stageO.js，未改 appearance/NPC_SPEC/学校场景
00:25 · [Stage O] 医院复诊自动重开服药疗程（onHospitalRevisit / 护士路径）
00:25 · [Stage O] 试穿对比 HUD 徽章（原外观→试穿）
00:25 · [Stage O] 时段软行程链（公交/便利店/面馆/奶茶/门岗）POI 软链
00:25 · [Stage O] 门禁长图加水印 + 演示二维码
00:25 · [Stage O] 质量：stageO_test 9/9 · smoke 4/4 · stage6 12/12 · 截图 o1–o6

00:35 · [Stage P] SLA 逾期→物业上门对话（结案/续期/改约），纯菜单无 atlas · js/stageP.js
00:35 · [Stage P] 复诊+药房统一 careSM（revisit→挂号→问诊→取药→疗程）
00:35 · [Stage P] 试穿徽章一键还原上一套（setOutfitId）
00:35 · [Stage P] 软行程写入 dayLog itin_replay + 今日路线回放
00:35 · [Stage P] 长图 QR 深链 fushi://app/scanlog → 门禁 App
00:35 · [Stage P] 质量：stageP_test 8/8 · smoke 4/4 · stage6 12/12 · 截图 p1–p6 · 未改外观/学校

00:45 · [Stage Q] 物业上门预约时间槽（今/明）+ 到点履约对话 · js/stageQ.js
00:45 · [Stage Q] 手机「健康」页可视化 careSM + 疗程/漏服
00:45 · [Stage Q] 试穿多步撤销栈（↩×n HUD）
00:45 · [Stage Q] 今日路线回放分享微信小结（阿凯/阿姨）
00:45 · [Stage Q] 深链扩展 daylog / ticket / scanlog
00:45 · [Stage Q] 质量：stageQ_test 8/8 · smoke 4/4 · stage6 12/12 · 截图 q1–q6 · 未改外观/学校

00:55 · [Stage R] 物业预约改期/爽约 + 租户评分 · js/stageR.js
00:55 · [Stage R] 健康页服药周报（依从性进度条，可发阿姨）
00:55 · [Stage R] 试穿栈 + 衣柜收藏夹（HUD ★ / 健康页穿上）
00:55 · [Stage R] 路线→周常通勤模板（保存/套用）
00:55 · [Stage R] 统一深链路由 + 顶部通知栏捷径
00:55 · [Stage R] 质量：stageR_test 8/8 · smoke 4/4 · stage6 12/12 · 截图 r1–r6 · 未改外观/学校

01:05 · [Stage S] 信用评分→门禁续期折扣/押金优惠联动 · js/stageS.js
01:05 · [Stage S] 服药周报近7日热力格
01:05 · [Stage S] 衣柜收藏按季节置顶
01:05 · [Stage S] 通勤模板早晨闹钟提醒
01:05 · [Stage S] 通知栏可折叠 + 捷径自定义顺序
01:05 · [Stage S] 质量：stageS_test 8/8 · smoke 4/4 · stage6 12/12 · 截图 s1–s6 · 未改外观/学校/store/npc_schedule
